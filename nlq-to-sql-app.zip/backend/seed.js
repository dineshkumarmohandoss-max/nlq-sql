import sqlite3 from "sqlite3";

const db = new sqlite3.Database("./database.db");

db.serialize(() => {
  console.log("🗑️ Dropping old tables...");
  db.run("DROP TABLE IF EXISTS Customers");
  db.run("DROP TABLE IF EXISTS Employees");
  db.run("DROP TABLE IF EXISTS Orders");
  db.run("DROP TABLE IF EXISTS Products");
  db.run("DROP TABLE IF EXISTS Categories");
  db.run("DROP TABLE IF EXISTS Suppliers");
  db.run("DROP TABLE IF EXISTS Shippers");

  console.log("🛠️ Creating tables...");

  db.run(`
    CREATE TABLE Customers (
      CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
      CompanyName TEXT,
      ContactName TEXT,
      Country TEXT
    )
  `);

  db.run(`
    CREATE TABLE Employees (
      EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT,
      FirstName TEXT,
      LastName TEXT,
      Title TEXT
    )
  `);

  db.run(`
    CREATE TABLE Orders (
      OrderID INTEGER PRIMARY KEY AUTOINCREMENT,
      CustomerID INTEGER,
      EmployeeID INTEGER,
      OrderDate TEXT,
      FOREIGN KEY(CustomerID) REFERENCES Customers(CustomerID),
      FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
    )
  `);

  db.run(`
    CREATE TABLE Categories (
      CategoryID INTEGER PRIMARY KEY AUTOINCREMENT,
      CategoryName TEXT
    )
  `);

  db.run(`
    CREATE TABLE Suppliers (
      SupplierID INTEGER PRIMARY KEY AUTOINCREMENT,
      CompanyName TEXT,
      Country TEXT
    )
  `);

  db.run(`
    CREATE TABLE Products (
      ProductID INTEGER PRIMARY KEY AUTOINCREMENT,
      ProductName TEXT,
      SupplierID INTEGER,
      CategoryID INTEGER,
      UnitPrice REAL,
      FOREIGN KEY(SupplierID) REFERENCES Suppliers(SupplierID),
      FOREIGN KEY(CategoryID) REFERENCES Categories(CategoryID)
    )
  `);

  db.run(`
    CREATE TABLE Shippers (
      ShipperID INTEGER PRIMARY KEY AUTOINCREMENT,
      CompanyName TEXT,
      Phone TEXT
    )
  `);

  console.log("🌱 Inserting sample data...");

  db.run("INSERT INTO Customers (CompanyName, ContactName, Country) VALUES ('Alfreds Futterkiste', 'Maria Anders', 'Germany')");
  db.run("INSERT INTO Customers (CompanyName, ContactName, Country) VALUES ('Around the Horn', 'Thomas Hardy', 'UK')");
  db.run("INSERT INTO Customers (CompanyName, ContactName, Country) VALUES ('Bon App', 'Laurence Lebihan', 'France')");

  db.run("INSERT INTO Employees (FirstName, LastName, Title) VALUES ('Nancy', 'Davolio', 'Sales Representative')");
  db.run("INSERT INTO Employees (FirstName, LastName, Title) VALUES ('Andrew', 'Fuller', 'Vice President of Sales')");

  db.run("INSERT INTO Orders (CustomerID, EmployeeID, OrderDate) VALUES (1, 1, '2023-07-01')");
  db.run("INSERT INTO Orders (CustomerID, EmployeeID, OrderDate) VALUES (2, 2, '2023-07-15')");

  db.run("INSERT INTO Categories (CategoryName) VALUES ('Beverages')");
  db.run("INSERT INTO Categories (CategoryName) VALUES ('Condiments')");

  db.run("INSERT INTO Suppliers (CompanyName, Country) VALUES ('Exotic Liquids', 'UK')");
  db.run("INSERT INTO Suppliers (CompanyName, Country) VALUES ('New Orleans Cajun Delights', 'USA')");

  db.run("INSERT INTO Products (ProductName, SupplierID, CategoryID, UnitPrice) VALUES ('Chai', 1, 1, 18.00)");
  db.run("INSERT INTO Products (ProductName, SupplierID, CategoryID, UnitPrice) VALUES ('Aniseed Syrup', 1, 2, 10.00)");
  db.run("INSERT INTO Products (ProductName, SupplierID, CategoryID, UnitPrice) VALUES ('Cajun Seasoning', 2, 2, 22.00)");

  db.run("INSERT INTO Shippers (CompanyName, Phone) VALUES ('Speedy Express', '123-4567')");
  db.run("INSERT INTO Shippers (CompanyName, Phone) VALUES ('United Package', '987-6543')");

  console.log("✅ Northwind-like DB seeded!");
});

db.close();
