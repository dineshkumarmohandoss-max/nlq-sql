import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import sqlite3 from "sqlite3";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database("./database.db");

app.post("/api/nlq-to-sql", async (req, res) => {
  const { query, schema } = req.body;

  try {
    const llmResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a SQL generator. Convert NLQ to SQL based on schema.\nSchema:\n${schema}`,
          },
          { role: "user", content: query },
        ],
      }),
    });

    const llmData = await llmResponse.json();
    const sqlQuery = llmData.choices[0].message.content.trim();

    console.log("Generated SQL:", sqlQuery);

    db.all(sqlQuery, [], (err, rows) => {
      if (err) {
        console.error("❌ SQL error:", err.message);
        return res.status(400).json({ sql: sqlQuery, error: err.message });
      }
      res.json({ sql: sqlQuery, rows });
    });
  } catch (error) {
    console.error("❌ Server error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.listen(5000, () => console.log("✅ Backend running at http://localhost:5000"));
