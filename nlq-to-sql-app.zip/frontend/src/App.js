import React, { useState } from "react";

function App() {
  const [query, setQuery] = useState("");
  const [sql, setSql] = useState("");
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    setError("");
    setSql("");
    setResults([]);

    const schema = `
    Tables:
      Customers(CustomerID, CompanyName, ContactName, Country)
      Employees(EmployeeID, FirstName, LastName, Title)
      Orders(OrderID, CustomerID, EmployeeID, OrderDate)
      Categories(CategoryID, CategoryName)
      Suppliers(SupplierID, CompanyName, Country)
      Products(ProductID, ProductName, SupplierID, CategoryID, UnitPrice)
      Shippers(ShipperID, CompanyName, Phone)
    Relationships:
      Orders.CustomerID → Customers.CustomerID
      Orders.EmployeeID → Employees.EmployeeID
      Products.CategoryID → Categories.CategoryID
      Products.SupplierID → Suppliers.SupplierID
    `;

    try {
      const response = await fetch("http://localhost:5000/api/nlq-to-sql", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, schema }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Unknown error occurred");
        setSql(data.sql || "");
        return;
      }

      setSql(data.sql || "");
      setResults(data.rows || []);
    } catch (err) {
      setError("⚠️ Failed to connect to backend");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>NLQ → SQL Generator (Northwind)</h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Ask (e.g., list all customers in Germany)"
        style={{ width: "400px", padding: "8px" }}
      />
      <button onClick={handleSubmit} style={{ marginLeft: "10px", padding: "8px" }}>
        Run
      </button>

      {error && (
        <div style={{ marginTop: "20px", color: "red" }}>
          <h3>Error:</h3>
          <p>{error}</p>
        </div>
      )}

      {sql && (
        <div style={{ marginTop: "20px" }}>
          <h3>Generated SQL:</h3>
          <pre>{sql}</pre>
        </div>
      )}

      {results.length > 0 && (
        <div style={{ marginTop: "20px" }}>
          <h3>Results:</h3>
          <table border="1" cellPadding="8" style={{ borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {Object.keys(results[0]).map((col) => (
                  <th key={col}>{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.map((row, i) => (
                <tr key={i}>
                  {Object.values(row).map((val, j) => (
                    <td key={j}>{val}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
