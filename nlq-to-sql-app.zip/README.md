# NLQ to SQL App

This project converts natural language queries (NLQ) into SQL queries using an LLM and executes them against a **Northwind-like SQLite database**.

## 📂 Structure

- **backend/** → Node.js + Express + SQLite + LLM (OpenAI)
- **frontend/** → React app

## 🚀 How to Run

### Backend
```bash
cd backend
npm install
node seed.js   # create + seed Northwind-like DB
npm start      # start server on http://localhost:5000
```

### Frontend
```bash
cd frontend
npm install
npm start      # start React app on http://localhost:3000
```

## Example Queries
- "list all customers"
- "show all products with their categories"
- "get all orders with customer and employee name"
- "list suppliers from UK"
- "show shippers and their phone numbers"
